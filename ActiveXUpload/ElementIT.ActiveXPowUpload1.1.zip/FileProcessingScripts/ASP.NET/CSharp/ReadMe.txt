ASP.NET has native object that stores uploaded files. Native ASP.NET version 1, 1.1 object has one seriouse disadvantage: It uses memory equal to files size. If you uploads large files you can get "out of memory" error. 

May be you will be interested in our another product PowUpload ASP.NEt control (http://www.powupload.com/). PowUpload handles and stores the contents of the POST request to a file on the server hard disk rather than loading it into memory as the built-in ASP.NET upload support does. 
PowUpload provides rich server-side progress indicator that lets users to monitor the progress of their uploads and some ather advanced features.



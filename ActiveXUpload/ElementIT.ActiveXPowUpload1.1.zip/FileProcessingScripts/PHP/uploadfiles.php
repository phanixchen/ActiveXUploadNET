<?php
// In PHP versions earlier than 4.1.0, $HTTP_POST_FILES should be used instead
// of $_FILES.

echo 'Upload result:<br>';

$uploaddir = dirname($_SERVER['SCRIPT_FILENAME'])."/UploadedFiles/";

$target_encoding = "ISO-8859-1";

if(count($_FILES) > 0)
	foreach($_FILES as $name=>$arrfile)
	{
		$uploadfile = $uploaddir . iconv("UTF-8", $target_encoding,basename($arrfile['name']));

		if (move_uploaded_file($arrfile['tmp_name'], $uploadfile))
		   echo "File ".$arrfile['name']." is valid, and was successfully uploaded.<br>";
	}




?>
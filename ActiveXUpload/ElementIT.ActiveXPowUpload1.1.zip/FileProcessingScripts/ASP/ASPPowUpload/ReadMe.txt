

ASPPowUpload is an ASP control that enables an ASP application to capture and save files uploaded to 
the web server by a browser. ASPPowUpload is fully compatible with the standard files upload protocol defined 
in RFC1867 for the HTML POST Form with the <INPUT TYPE=FILE> tags. 

ASPPowUpload handles and stores the contents of the POST request to a file on the server hard disk 
rather than loading it into memory. PowUpload provides rich server-side progress indicator that lets 
users to monitor the progress of their uploads. 

Visit our website http://www.element-it.com for more info.

Before running this sample you should download ASPPowUpload distibutive and register ASPPowUpload.dll control!!!
 
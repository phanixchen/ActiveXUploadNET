ASP havn't native object that stores uploaded files therefore you need to have some ASP script that would parse the data array returned by Request, extract individual file, and save them on hard drive. Also there are some professional COM+ controls that are more reliable and has some advanced features than clear ASP script. 

You can find some professional upload controls at http://www.hotscripts.com/ASP/Scripts_and_Components/File_Manipulation/index.html web site, or 
you can try our ASPPowUpload product (See sample at ASP\ASPPowUpload\ folder). ASPPowUpload is commercial product and you should buy license if you will use it.

Here you can find free ASP script "uploadfiles.asp" that processes uploaded files. By default script saves files to folder "\UploadedFiles". You can modify code in any text editor. 

ASP script has some seriouse disadvantages: 

It can't upload large files (greater than 60 MB) 
Uses memory equal to files size. 

Professional upload controls like ASPPowUpload will save you these troubles. 
/* usage: 
<script name> [<hhc file> [<contents file>]] */

var HhcFileName = "a.hhc";
var ContentsFileName = "contents.html";
var ForWriting = 2;

// processing command line arguments
var oArgs = WScript.Arguments;
if(oArgs.length > 0)
	HhcFileName = oArgs(0);
if(oArgs.length > 1)
	ContentsFileName = oArgs(1);
	
HhcFileName = GetPath() + HhcFileName;
ContentsFileName = GetPath() + ContentsFileName;

// -------------------------------------- ChhcDOMTree class --------------------------------------------
function ChhcDOMTree(FileName) {
	this.oIE = WScript.CreateObject("InternetExplorer.Application", "IE_");
	this.oIE.navigate(FileName);
	//oIE.Offline = true;
	//oIE.visible = 1;
	//oIE.Silent = true;

	// wait for Internet Explorer to load the document
	while (this.oIE.Busy) {
		WScript.Sleep(500);
	}
	
	this.RecCount = 0;
	this.document = this.oIE.Document;
}

ChhcDOMTree.prototype.GetString = function() 
{
	var oTree = this.oIE.Document.getElementById("treeRoot");
	var treeObj = this.ExpandTree(oTree);
	return treeObj.outerHTML;
}

ChhcDOMTree.prototype.CreateHeading = function (name, local) 
{
 	var myObject = this.CreateTreeObject("Heading", name, local)
	var liObj = this.document.createElement("LI")
	liObj.appendChild(myObject)
	
	return liObj;
}

ChhcDOMTree.prototype.CreateTopic = function (name, local)
{
	var myObject = this.CreateTreeObject("Topic", name, local)
	var liObj = this.document.createElement("LI")
	liObj.appendChild(myObject)
	
	return liObj;
}

ChhcDOMTree.prototype.CreateTreeObject = function (type, name, local)
{	
	var myObject = this.document.createElement("OBJECT")
	var param = this.document.createElement("PARAM")
	
	myObject.setAttribute("type","text/sitemap")
	
	param.setAttribute("name","Name")
	param.setAttribute("value", name)
	myObject.appendChild(param)
	
	param = this.document.createElement("PARAM")
	param.setAttribute("name","Local")
	param.setAttribute("value", local)
	myObject.appendChild(param)
	
	
	if (type == "Heading")
	{
		param = this.document.createElement("PARAM")
		param.setAttribute("name","ImageNumber")
		param.setAttribute("value", "2")
		myObject.appendChild(param)
	}
	
 return myObject;
}
	
ChhcDOMTree.prototype.parsDIV = function (divobj)
{
	var linkObject
	var shortLink
		
	if (divobj.hasChildNodes())
	{
		for (var Count = 0;Count < divobj.childNodes.length;Count++)
		{
			linkObject = divobj.childNodes(Count)
			
			if (linkObject.tagName == "A")
			{
				shortLink = linkObject.getAttribute("href")
				shortLink = shortLink.substring(shortLink.lastIndexOf("/") + 1)
				var valueArr = [linkObject.innerText, shortLink]
			}
		}
	
	}
	return valueArr;
}

ChhcDOMTree.prototype.ExpandTree = function (tree)
{ 	
	var ULObj = this.document.createElement("UL")
	var elementObj
	var valueArr = new Array
	
	this.RecCount++
	
	if (tree.hasChildNodes())
	{
		for (var Count = 0;Count < tree.childNodes.length; Count++)
		{
			elementObj = tree.childNodes(Count)
			
			if (elementObj.tagName == "DIV")
			{
				
				if (this.hasChildTreeNode(elementObj))
				{
					/*if (ULObj.childNodes.length > 1)
					{ 
						valueArr = this.parsDIV(tree.childNodes(Count - 1))
						
					}
					else
					{*/
						valueArr = this.parsDIV(elementObj)
					//}					
					
					//ULObj.replaceChild(this.CreateHeading(valueArr[0], valueArr[1]), ULObj.lastChild)
					ULObj.appendChild(this.CreateHeading(valueArr[0], valueArr[1]))
					ULObj.appendChild(this.ExpandTree(this.FirstDivChild(elementObj)))
				}
				else
				{
					try
					{
						valueArr = this.parsDIV(elementObj)					
						ULObj.appendChild(this.CreateTopic(valueArr[0], valueArr[1]))
					}
					catch(ex)
					{
						WScript.Echo(elementObj.innerHTML + " : " + valueArr  + " : " + ex)
						// we will stop at the first error
						throw ex;
					}
										
				}
							
			}
		}
		
		return ULObj;
	}
}

ChhcDOMTree.prototype.hasChildTreeNode = function (divobj)
{
	if (divobj.hasChildNodes())
	{
		for (var Count = 0;Count < divobj.childNodes.length; Count++)
		{
			if (divobj.childNodes(Count).tagName == "DIV")
			{
				return true;
			}
				
		}
	}
		
	return false;
}

ChhcDOMTree.prototype.FirstDivChild = function (parent)
{
	if (parent.hasChildNodes())
	{	
		for (var Count = 0;Count < parent.childNodes.length; Count++)
		{
			if (parent.childNodes(Count).tagName == "DIV")
			{
				return parent.childNodes(Count);
			}
				
		}
	}
}
// ------------------------------- end of ChhcDOMTree object -----------------------------------------

function GenerateHhcStr(treestr) {
	return  ""
	+ '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">\n'
	+ '<HTML>\n'
	+ '<HEAD>\n'
	+ '<meta name="GENERATOR" content="Microsoft&reg; HTML Help Workshop 4.1">\n'
	+ '<!-- Sitemap 1.0 -->\n'
	+ '</HEAD><BODY>\n'
	+ '<OBJECT type="text/site properties">\n'
	+ '<param name="Window Styles" value="0x800025">\n'
	+ '<param name="ImageType" value="Folder">\n'
	+ '</OBJECT>\n'		
	+ GenerateHhcTreeStr(treestr)
	+ '\n</BODY></HTML>\n';
}

function GenerateHhcTreeStr(treestr) {
	return treestr
	.replace(/([^\n])</g, "$1\n<")
	.replace(/(<li>)[\s\n]*/ig, "$1 ")
	.replace(/<\/li>[\s\n]*/ig, "")
	.replace(/type=text\/sitemap/g, 'type="text/sitemap"')
	;
}

function GetPath() {
	var path = WScript.ScriptFullName;
	path = path.substr(0, path.lastIndexOf("\\") + 1);
	return path;
}

function WriteToFile(str, FileName) {
	var fso = WScript.CreateObject("Scripting.FileSystemObject");
	var txtStreamOut = fso.OpenTextFile(FileName, ForWriting, true);
	txtStreamOut.Write(str);
	txtStreamOut.Close();
}


var hhcDOMTree = new ChhcDOMTree(ContentsFileName);
var treestr = hhcDOMTree.GetString();
var HhcFileStr = GenerateHhcStr(treestr);

WriteToFile(HhcFileStr, HhcFileName);
WScript.Echo("Done");

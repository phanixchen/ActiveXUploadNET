#!/usr/bin/perl

use Warnings;
use File::Find;
use English;

# usage:
# <script name> [<hhp file>]

my $HhpFile = "a.hhp";
my @SourceFiles = ();
my %IgnoreHtmlFiles = ("contents.html" => undef, "index.html" => undef);

if (scalar @ARGV > 0) {
	$HhpFile = $ARGV[0];
}

sub wanted() {
	my $name = $File::Find::name;
	# remove leading "./" component
	if($name =~ m'^\./') {
		$name = substr($name, 2);
	}
	if($name =~ m'\.html$') {
		if(not exists $IgnoreHtmlFiles{$name}) {
			push @SourceFiles, $name;
		}
	}
}

sub preprocess() {
	my @out = ();
	# exclude svn directories from search
	foreach $i (@_) {
		next if $i eq ".svn";
		push @out, $i;
	}
	@out;
}

# see result in the @SourceFiles global array
sub CalculateSourceFiles() {
	find({wanted => \&wanted, preprocess => \&preprocess}, ("."));
}

sub PrintSourceFiles() {
	foreach $i (@SourceFiles) {
		print "$i\n";
	}
}

sub ProcessHhpFile() {
	my $HhpFileContents;
	# read hhp file
	{
		local $/=undef;
		open FILE, "$HhpFile" or die "Unable to open file $HhpFile";
		$HhpFileContents = <FILE>;
		close FILE;
	}

	# prepare file list
	&CalculateSourceFiles();
	my $SourceFileList = join "\n", @SourceFiles;
	$SourceFileList .= "\n";

	# Change file contents
	unless($HhpFileContents
		 =~ s|^(\[FILES\]\s*\n)(.*?)^\s*$|$1${SourceFileList}|sm) {
		die "Wrong file format";
	}

	# save data back to file
	open FILE, ">", "$HhpFile" or die "Unable to open file $HhpFile";
	print FILE $HhpFileContents;
	close FILE;
}

&ProcessHhpFile();

